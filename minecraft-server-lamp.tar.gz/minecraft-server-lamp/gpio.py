
import RPi.GPIO as GPIO

def off(n):
        GPIO.output(n, True)

def on(n):
        GPIO.output(n, False)

GPIO.setmode(GPIO.BCM)
GPIO.setup(17, GPIO.OUT)

while True:
	s = raw_input("")
	print(s)
	split = s.split("[@] ")
	if len(split) > 1:
		cmd = split[1].split(",")	
		print("="+split[1])
		if len(cmd) > 1:
			print("GPIO: "+cmd[0]+" is: "+cmd[1])
			if cmd[1] == "on":
				on(int(cmd[0]))
			else:
				off(int(cmd[0]))
